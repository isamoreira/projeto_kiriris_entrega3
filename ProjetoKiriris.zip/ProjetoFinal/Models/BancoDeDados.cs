﻿using Microsoft.EntityFrameworkCore;

namespace ProjetoFinal.Models
{
    public class BancoDeDados : DbContext
    {
        public DbSet<ProdutosDaMandiocultura> ProdutosDaMandiocultura { get; set; }

        public DbSet<VendaDeArtesanatos> VendaDeArtesanatos { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)

        {   
            //@"server=meuservidorb.database.windows.net;database=DbTeste08;User ID=adminserver;Password=YsRt$sql"
            //Server=.; Database=dbTesteKiriris1; User ID=SA; Password=YsRt$sql;
            optionsBuilder.UseSqlServer(connectionString: @"server=.;database=myDb;User ID=SA; Password=YsRt$sql");
        }
    }
}
